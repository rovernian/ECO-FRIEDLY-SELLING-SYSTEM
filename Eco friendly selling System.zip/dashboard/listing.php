
<?php
include("header.php");
include("../includes/db_con.php");
   ?>    
   <!-- <div class="w3-card-5"> 
          <div class="box-8">     -->   
    <form action="../functions/postListingImages.php" method="post" enctype = "multipart/form-data" >
      <div class="create_listing text-center ">   
      <h2><svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-plus-lg" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2Z"/>
</svg>Create new Listing</h2>

<input type="file" name="fileToUpload" id="fileToUpload" class="files"placeholder="file" multiple><br>
<label for="fileToUpload">
<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-file-arrow-up" viewBox="0 0 16 16">
  <path d="M8 11a.5.5 0 0 0 .5-.5V6.707l1.146 1.147a.5.5 0 0 0 .708-.708l-2-2a.5.5 0 0 0-.708 0l-2 2a.5.5 0 1 0 .708.708L7.5 6.707V10.5a.5.5 0 0 0 .5.5z"/>
  <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H4zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1z"/>
</svg>
Upload File
</label>
      <input type="text"  class="w3-input" class="form-control"  name="title" id="name" placeholder="Title" required> <br>
      <input type="number"  class="w3-input" class="form-control"  name="price" id="price" placeholder="Price" required><br>
      <input type="number"  class="w3-input" class="form-control"  name="Quantity" id="Quantity" placeholder="Quantity"required><br>
      <select  class="w3-input" class="form-control" name="cat" id="category" required>
        <option value="0"id="pick">Choose Categories</option>
        <?php
          $select = "SELECT * FROM `category`"; 
          $result_query = mysqli_query($conn, $select);
            while($row=mysqli_fetch_assoc($result_query)){
              $category_title=$row['category_title'];
              $id=$row['id'];
              echo " <option value='$id'>$category_title</option>";
            }
        ?>
      </select><br>
        <textarea  class="w3-input" class="form-control" name="description" id="text" cols="30" rows="3" placeholder="Description" required></textarea><br>
        <button type="submit" id="btnPostListing" name="submit" >Post</button>
      </div>
    </form>

    <script src="../javaScript/jquery.js"></script>
    <script src="../javaScript/listing.js"></script>
<?php include ("header.php");?>
<body>
<div class="head">
	<div class="box-8">
	  <div class="content-box">
    <table>
  <thead>
    <tr>
      <th scope="col">Customer</th>
      <th scope="col">Product name</th>
      <th scope="col">Price</th>
      <th scope="col">total price</th>
      <th scope="col">Qt</th>
      <th scope="col">Date Ordered</th>
      <th scope="col">Date Deliver</th>
      <th scope="col">Type of Payment</th>
      <th scope="col">Status</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
    <tbody id="addTableToAppend">
      
    </tbody>
  </table>
    </div>
    </div>
</div>
</body>
  <script src="../javaScript/jquery.js"></script>
  <script src="../javaScript/customerOrder.js"></script>
</html>
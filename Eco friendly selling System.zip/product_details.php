<?php
include "includes/db_con.php";
include ("includes/header.php");
include "functions/index_function.php";
?>

    <body>
        <div class="modal fade" id="addtocart" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Add this Product</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div id="addthisItemToCart"></div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" id="addThisProductToCart" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </div>
            </div>
        </div>


<header class="header">

    <a href="dashboard.php" class="logo"> <i class="fas fa-shopping-basket"></i> Ecoshop </a>

             <nav class="navbar">
        <a href="dashboard.php">home</a>
        <a href="./ecopost/index.php">Ecopost</a>
        <a href="./dashboard/index.php">My dashboard</a>

    </nav>
    <div class="icons">
        <div class="fas fa-bars" id="menu-btn"></div>
        <div class="fas fa-search" id="search-btn"></div>
        <a href="./shopcart.php"><div class="fas fa-shopping-cart" id="cart-btn"><sup id="cartNumber"></sup></div></a>
        <div class="fas fa-arrow-right-from-bracket" id="btnLogout"> <sup><svg xmlns="http://www.w3.org/200/svg" viewBox="-250 -230 920 1000"><path d="M502.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L402.7 224 192 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l210.7 0-73.4 73.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l128-128zM160 96c17.7 0 32-14.3 32-32s-14.3-32-32-32L96 32C43 32 0 75 0 128L0 384c0 53 43 96 96 96l64 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-64 0c-17.7 0-32-14.3-32-32l0-256c0-17.7 14.3-32 32-32l64 0z"/></svg></sup></div></a>
    </div>

    <form action="search.php" class="search-form" method="get">
        <input type="search" id="searchProduct" name="searchProduct" placeholder="search here...">
        <label for="search-box" id="search_now" name="search_now" id="btnSearch" class="fas fa-search"></label>
    </form>


</header>
<section>  <div class="rows">
        <div class="col-md-20">
            <div class="row-1">
            <?php
                product_image_1();
            ?>
            </div>
        </section>
        <section>
            <div class="row-2">
                <h3>Product Description</h3>
                <?php
                product_decription();
                ?>
            </div>  
        </section>
          

  
    <section>    
            <div class="row col-12 ">
                <div class=" fs-6s text-center">Product Rating</div>
                <div class="col-12 ms-3">
                    <div class="col-2 mb-2">
                        <select name="rating" id="rating" class="form-control">
                            <option value="0">Rate this item</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </div>
                    <div class="col-11">
                        <div class="textCommentArea">
                            <textarea name="commentTextArea" class="form-control" id="commentTextArea" rows="5" placeholder="Enter comments here"></textarea>
                            <button type="button" id="btnCommentHere" class="btn btn-primary mt-2">Submit comment</button>
                        </div>
                    </div>
                    <div class="commentsHere mt-5 ms-2">
                        <div id="appendAllComment"></div>
                    </div>
                </div>
            </div>
        </div>
</section>
        
<?php
include("includes/footer.php");
?>

<script src="./includes/script.js"></script>
<script src="javaScript/jquery.js"></script>
<script src="javaScript/dashboard.js"></script>
<script src="javaScript/toggle.js"></script>
<script src="javaScript/userInformation.js"></script>
<script src="javaScript/product_Details.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body></html>

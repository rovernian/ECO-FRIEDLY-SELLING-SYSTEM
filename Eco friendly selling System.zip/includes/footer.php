
<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3> Ecoshop<i class="fas fa-shopping-basket"></i> </h3>
            <p>Better Environment, Better Tomorrow. Save the planet Earth. Let us make our planet a better place. Stop polluting..</p>
            <div class="share">
                <a href="#" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>
        </div>

        
        <div class="box">
            <h3>About us</h3>
            <p>This shopping website offers information on environmentally friendly products. Using such products has many advantages; in addition to being better for the environment, it also directly improves your and your loved ones' health</p>
           
        </div>

        <div class="box">
            <h3>Eco Quotes</h3>
           <p>“Be part of the solution, not part of the pollution.”
           “The most environmentally friendly product is the one you didn’t buy.”
           “Plastic will be the main ingredient of all our grandchildren’s recipes.”
         </p>

        </div>

    </div>

    <div class="credit"> created by <span> Ecoteam </span> | all rights reserved </div>

</section>

<!-- footer section ends -->










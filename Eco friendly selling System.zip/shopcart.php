<?php
include("./includes/header.php");
?>

<!DOCTYPE html>
<html lang="en">


<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
	<title>table cart</title>
	<link rel="stylesheet" href="css/main.min.css">
    <link rel="stylesheet" href="css/checkout.css">
     <link rel="stylesheet" href="css/color.css">
	 <link rel="stylesheet" href="css/style.css">
	
</head>
<div class="modal fade" id="addCheckOut" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Please fill up the form</h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="addthisItemToCart">
                    
                </div>
            </div>
            </div>
        </div>
</div>
Write to CAPSTONE PROJECT

    
<!-- header section starts  -->

<header class="header">

    <a href="#" class="logo"> <i class="fas fa-shopping-basket"></i> Ecoshop </a>

    <nav class="navbar">
        <a href="dashboard.php">home</a>
        <a href="#products">products</a>
        <a href="./ecopost/newsfeed.php">Ecopost</a>
        <a href="./dashboard/index.php">My dashboard</a>

    </nav>

    <div class="icons">
        <div class="fas fa-bars" id="menu-btn"></div>
        <div class="fas fa-search" id="search-btn"></div>
        <div class="fas fa-shopping-cart" id="cart-btn"><sup id="cartNumber"></sup></div>
        <div class="fas fa-user" id="login-btn"class="profilePic"></div>
    </div>

    <form action="search.php" class="search-form" method="get">
        <input type="search" id="search-box"name="searchProduct" id="searchProduct" placeholder="search here...">
        <label for="search-box"  name="search_now" id="btnSearch" class="fas fa-search"></label>
    </form>


</div>

</header>

<body>
	<section>



<table class="table ">
  <thead>
    <tr>
      <th scope="col">Product Name</th>
      <th scope="col">Price</th>
      <th scope="col">Quantity</th>
      <th scope="col">Total Price</th>
      <th scope="col">Action</th>
      <th scope="col">Check out</th>

    </tr>
  </thead>
  <tbody id="tblCart">
  
   
  </tbody>
</table>

    </section><!-- CART SECTION -->
	
	
	 <script src="javaScript/jquery.js"></script>
    <script src="javaScript/cartTable.js"></script>
    <script src="javaScript/userInformation.js"></script>
    <script src="javaScript/UserLogout.js"></script>
	<script src="js/main.min.js"></script>
	<script src="js/userincr.js"></script>
	<script src="js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>	


</html>
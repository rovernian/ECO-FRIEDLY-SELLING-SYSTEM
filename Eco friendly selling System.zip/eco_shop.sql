-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 30, 2023 at 11:25 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eco_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(11) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `image` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `price` varchar(255) NOT NULL,
  `Qt` varchar(255) NOT NULL,
  `total_price` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `product_id`, `user_id`, `username`, `image`, `title`, `price`, `Qt`, `total_price`) VALUES
(5, '1', '40', '', 'TB0137J Raw Jute supermarker bag.png', 'd', '12', '1', '12'),
(7, '1', '40', '', 'TB0137J Raw Jute supermarker bag.png', 'd', '12', '1', '12'),
(8, '1', '40', '', 'TB0137J Raw Jute supermarker bag.png', 'd', '12', '1', '12'),
(9, '1', '40', '', 'TB0137J Raw Jute supermarker bag.png', 'd', '12', '1', '12'),
(10, '1', '40', '', 'TB0137J Raw Jute supermarker bag.png', 'd', '12', '1', '12'),
(11, '1', '41', '', 'TB0137J Raw Jute supermarker bag.png', 'd', '12', '1', '12'),
(16, '4', '44', '', '3774f2_e9b4b4d7d5fe47a588c6232f0a38e0a6~mv2.webp', 'nice', '234', '1', '234'),
(17, '4', '44', '', '3774f2_e9b4b4d7d5fe47a588c6232f0a38e0a6~mv2.webp', 'nice', '234', '1', '234'),
(19, '4', '51', '', '3774f2_e9b4b4d7d5fe47a588c6232f0a38e0a6~mv2.webp', 'nice', '234', '1', '234');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category_title` varchar(100) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category_title`, `image`) VALUES
(2, 'Eco-friendly Bags', 'eco-jute-bags.jpeg'),
(3, 'Eco-friendly Handmade', 's-l1600.jpg'),
(4, 'Eco-friendly Packaging', 'From-Beginning-to-End-Biodegradable-Packaging-Options.jpg'),
(5, 'dd', 'collab2.png'),
(6, 'f', 'code.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `user_id` varchar(225) NOT NULL,
  `product_id` varchar(225) NOT NULL,
  `postId` int(11) NOT NULL,
  `comments` text NOT NULL,
  `rating` int(11) NOT NULL,
  `date_create` varchar(225) NOT NULL DEFAULT '0',
  `date_Updated` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `user_id`, `product_id`, `postId`, `comments`, `rating`, `date_create`, `date_Updated`) VALUES
(5, '40', '1', 0, 'naol', 2, '2023-04-21', '2023-04-21'),
(6, '44', '4', 0, 'frer', 3, '2023-04-21', '2023-04-21');

-- --------------------------------------------------------

--
-- Table structure for table `c_order`
--

CREATE TABLE `c_order` (
  `id` int(11) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `total_price` int(255) NOT NULL,
  `Qt` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `D_ordered` text NOT NULL,
  `D_deliver` text NOT NULL,
  `P_method` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `c_order`
--

INSERT INTO `c_order` (`id`, `user_id`, `title`, `total_price`, `Qt`, `address`, `D_ordered`, `D_deliver`, `P_method`, `status`) VALUES
(3, '51', 'nice', 234, '1', '', '2023-05-29', '2023-06-05', 'COD', '0');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `my_order`
--

CREATE TABLE `my_order` (
  `id` int(11) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `productUser_Id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `Qt` varchar(100) NOT NULL,
  `image` text NOT NULL,
  `d_ordered` date NOT NULL,
  `d_delivered` date NOT NULL,
  `p_method` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `my_order`
--

INSERT INTO `my_order` (`id`, `user_id`, `productUser_Id`, `title`, `price`, `total_price`, `Qt`, `image`, `d_ordered`, `d_delivered`, `p_method`, `status`) VALUES
(1, '41', 41, 'nice', '234', '234', '1', '3774f2_e9b4b4d7d5fe47a588c6232f0a38e0a6~mv2.webp', '2023-04-21', '2023-04-28', 'COD', '1'),
(2, '44', 41, 'nice', '234', '234', '1', '3774f2_e9b4b4d7d5fe47a588c6232f0a38e0a6~mv2.webp', '2023-04-21', '2023-04-28', 'COD', '1'),
(3, '51', 41, 'nice', '234', '234', '1', '3774f2_e9b4b4d7d5fe47a588c6232f0a38e0a6~mv2.webp', '2023-05-29', '2023-06-05', 'COD', '0');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `postId` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `caption` text NOT NULL,
  `d_c` varchar(225) NOT NULL,
  `d_u` varchar(225) NOT NULL,
  `imagePost` text NOT NULL,
  `video` text NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`postId`, `user_id`, `caption`, `d_c`, `d_u`, `imagePost`, `video`, `status`) VALUES
(5, 41, 'ka nice sa bag...', 'Friday 21st of April 2023 05:18:12 AM', 'Friday 21st of April 2023 05:18:12 AM', 'eco-jute-bags.jpeg', '', '0'),
(6, 43, 'hi', 'Friday 21st of April 2023 08:01:55 AM', 'Friday 21st of April 2023 08:01:55 AM', 's-l1600.jpg', '', '0'),
(7, 43, 'jndjs', 'Friday 21st of April 2023 08:04:05 AM', 'Friday 21st of April 2023 08:04:05 AM', 'handmade-paper-desing-500x500.webp', '', '0'),
(8, 43, 'jshdjsahjhsajd', 'Friday 21st of April 2023 08:04:48 AM', 'Friday 21st of April 2023 08:04:48 AM', 'images.jpg', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `price` int(255) NOT NULL,
  `Qt` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `date` text NOT NULL,
  `image_1` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `user_id`, `title`, `price`, `Qt`, `category`, `description`, `status`, `date`, `image_1`) VALUES
(4, '41', 'nice', 234, 1, '3', 'sdasd', 0, '04/21/2023', '3774f2_e9b4b4d7d5fe47a588c6232f0a38e0a6~mv2.webp'),
(5, '51', '', 0, 0, '0', '', 0, '05/29/2023', ''),
(6, '51', '', 0, 0, '0', '', 0, '05/29/2023', ''),
(7, '51', '', 0, 0, '0', '', 0, '05/29/2023', ''),
(8, '51', '', 0, 0, '0', '', 0, '05/29/2023', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(10012) NOT NULL,
  `password` varchar(250) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `address` varchar(100) NOT NULL,
  `role` varchar(10) NOT NULL DEFAULT 'user',
  `messageLink` varchar(225) NOT NULL,
  `status` int(10) NOT NULL DEFAULT 1,
  `d_c` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `d_u` varchar(100) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `fname`, `lname`, `email`, `username`, `password`, `phone`, `address`, `role`, `messageLink`, `status`, `d_c`, `d_u`, `image`) VALUES
(27, 'George Alfeser', 'Inoc', '123@go', 'sad', '202cb962ac59075b964b07152d234b70', '+6395653909', 'poblacion', 'admin', 'https://www.facebook.com/messages/t/100022549184462/?_rdc=1&_rdr', 1, '2023-04-13 18:05:09', '', '1st wallpaper.jpeg'),
(30, 'rovern`', 'berdos', 'berdos.rovern@gmail.com', 'ian', '202cb962ac59075b964b07152d234b70', '09066091566', 'dapitan', 'user', '', 1, '2023-04-29 23:31:20', '', ''),
(31, 'dre', 'inoc', 'dre@gmail.com', 'cute', '202cb962ac59075b964b07152d234b70', '09358207991', 'dapitan', 'admin', '', 1, '2023-04-19 09:49:20', '', 'logo.jpg'),
(40, 'cute', 'inoc', 'dre@', '123', '202cb962ac59075b964b07152d234b70', '12345678', '123', 'user', 'https://www.facebook.com/', 1, '2023-04-20 23:44:02', '', 'onepiece.jpg'),
(41, 'Wylene ', 'Sy', 'lene@', 'boding', '202cb962ac59075b964b07152d234b70', '0903123456', 'lapulapu', 'user', 'https://www.facebook.com/', 1, '2023-04-21 03:19:42', '', 'WIN_20211102_19_27_10_Pro.jpg'),
(42, 'rovern`', 'berdos', 'berdos.rovern@gmail.com', 'ian', '202cb962ac59075b964b07152d234b70', '09066091566', 'dapitan', 'user', '', 1, '2023-04-21 22:51:55', '', ''),
(43, 'test', 'test', 'test@', 'test', '202cb962ac59075b964b07152d234b70', '198980', 'llc', 'user', 'kljlkj', 1, '2023-04-21 09:45:35', '', 'code.jpeg'),
(44, 'dre', 'inoc', 'dre@', 'cute', '202cb962ac59075b964b07152d234b70', '123456789', 'gtfr', 'user', '', 1, '2023-04-21 12:34:30', '', ''),
(45, 'sdgd', 'dgad', 'dre@go', 'qa`', '202cb962ac59075b964b07152d234b70', 'dgdsgad', 'gadsgf', 'user', '', 1, '2023-04-29 23:29:17', '', 'code.jpeg'),
(46, 'sdgd', 'dgad', 'dre@go', 'qa`', '202cb962ac59075b964b07152d234b70', 'dgdsgad', 'gadsgf', 'user', '', 1, '2023-04-29 23:29:17', '', 'code.jpeg'),
(47, 'sdgd', 'dgad', 'dre@go', 'qa`', '202cb962ac59075b964b07152d234b70', 'dgdsgad', 'gadsgf', 'user', '', 1, '2023-04-29 23:29:17', '', 'code.jpeg'),
(48, 'sdgd', 'dgad', 'dre@go', 'qa`', '202cb962ac59075b964b07152d234b70', 'dgdsgad', 'gadsgf', 'user', '', 1, '2023-04-29 23:29:17', '', 'code.jpeg'),
(49, 'sdgd', 'dgad', 'dre@go', 'qa`', '202cb962ac59075b964b07152d234b70', 'dgdsgad', 'gadsgf', 'user', '', 1, '2023-04-29 23:29:17', '', 'code.jpeg'),
(50, 'sdgd', 'dgad', 'dre@go', 'qa`', '202cb962ac59075b964b07152d234b70', 'dgdsgad', 'gadsgf', 'user', '', 1, '2023-04-29 23:29:17', '', 'code.jpeg'),
(51, 'IAN', 'berdos', 'setsuna@123', 'ian', '202cb962ac59075b964b07152d234b70', '09066091566', 'dapitan', 'user', '', 1, '2023-05-26 06:23:34', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `c_order`
--
ALTER TABLE `c_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `my_order`
--
ALTER TABLE `my_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`postId`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `c_order`
--
ALTER TABLE `c_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `my_order`
--
ALTER TABLE `my_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `postId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

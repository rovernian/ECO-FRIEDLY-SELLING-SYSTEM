<?php
include ("header.php");
include "../includes/db_con.php";

if(isset($_POST['submit_cat'])){
    $category=$_POST['category_title'];
    $image=$_FILES['file']['name'];
    $temp_file=$_FILES['file']['tmp_name'];

if($category=='' or $image==''){
    echo "<script>alert('Please fill all the fields')</script>";
    exit();
    }else{
    move_uploaded_file($temp_file,"../dashboard/cat_uploads/$image");
   }


    $select = "SELECT category_title FROM category WHERE category_title = '$category'";
    $result =$conn->query($select);
    $num=mysqli_num_rows($result);
if($num> 0)
  {
    echo "<script>alert('This Category has been already in the Database!')</script>";
  } else{
    $sql = "INSERT INTO category (category_title,image)VALUES ('$category','$image')";
    $result=mysqli_query($conn,$sql);
if ($result) {
  echo "<script>alert('Category has been added successfully')</script>";
  } else {
  echo "Error: " . $sql . "<br>" . $conn->error;
  }
  }
}
$conn->close();
?>


<section class="content-header">
	<div class="content-header-left">
		<h1>Add Category</h1>
	</div>
	<div class="content-header-right">
		<a href="category.php" class="btn btn-primary btn-sm">View All</a>
	</div>
</section>

	<div class="col-md-12">
		<div class="box-body">
              <form action="" method="post" enctype = "multipart/form-data" >
              <div class="box box-info">
			  <div class="box-body" class="insert_category text-center ">
             
              <input type="file" name="file"  class="files" placeholder="file"><br>
			  <div class="col-sm-4">
			  <input type="text" class="form-control" name="category_title" placeholder="Category Title">
              </div>
			  <button type="submit" class="btn btn-success pull-left" name="submit_cat">Submit</button> 
              </div>           
              </form>
            </div>
		</div>
    </div>
<?php 
include('inc/script.php');
include('footer.php'); ?>
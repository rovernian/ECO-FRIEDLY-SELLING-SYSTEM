$(document).ready(function(){
    let tmp = localStorage.getItem('isloggedin');
    if (tmp == 404) {
        window.location.href = "./dashboard.php";
    }
    viewCarts();
    viewCartsNumber();
    doGetInfoUser();
    addCheckBox();
});

function addCheckBox(){
    $('#checkPrice').on('click', function() {
        var selectedCheckboxes = $('input[type="checkbox"]:checked');
        var selectedValues = []; 
        var totalSum = 0;

        selectedCheckboxes.each(function() {
            var value = parseInt($(this).val());
            selectedValues.push(value);
            totalSum += value;
        });
        $('#totalSum').empty().append("P "+totalSum);
    });
}

$('#checkOutItem').click(function(){
    $('#checkOutItem').on('click', function() {
        var selectedCheckboxes = $('input[type="checkbox"]:checked'); 
        var selectedValues = [];

        selectedCheckboxes.each(function() {
            selectedValues.push($(this).val());
        });

        $('#addthisItemToCart').empty().append(selectedValues);
    });
});

var doGetInfoUser =() =>{
    $.ajax({
      type: "POST",
      url: "./source/router.php",
      data: {choice: 'doGetInfoUser'},
      success: function(data){
        var json = JSON.parse(data);
        var str = "";
        var changeProfile = "";
        json.forEach(element => {
            str = element.email;
            changeProfile = `<img src="images/${element.image}" class="card-img-top" width="100" alt="..." onclick="toggleMenu()">`;
        });
        $('#nameOfUser').append(str);
        $('.profiles').append(changeProfile);
      },
      error: function(xhr, ajaxOptions, thrownError){
        alert(thrownError);
      }
    });
  }
  
  
var viewCarts =()=>{
    $.ajax({
    type: "POST",
    url: "./source/router.php",
    data: {choice: 'doGetCart'},
    success: function(data){
        var json = JSON.parse(data);
        var str = "";
        var count = 1;
        json.forEach(element => {
            str += 
            `
            <tr>
            <th scope="row"> <span><input type="checkbox"class="checkboxValue" id="${element.id}" value="${element.price}"></span><img src="./dashboard/product_uploads/${element.image}"class="image"width="140"alt=""> <span>${element.title}</span>
            </th>
            <td><span class="total-price">₱${element.price}</span>
            </td>
            <td>  <div class="cart-list-quantity">
            <div class="c-input-number">
                <span>
                    <input id="updateNumber" type="text" class="manual-adjust" value="${element.Qt}"/>
                </span>
            </div>
        </div></td>
            <td><span class="total-price">₱${element.price * element.Qt}</span>
            </td>
            <td>  <a href="#" title="" onclick="updateFunction(${element.id})"><svg xmlns="http://www.w3.org/2000/svg"  fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
            <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
            <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
          </svg></a>
            <a href="#" title="" onclick="deleteFunction(${element.id})"><svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-trash-fill" viewBox="0 0 16 16">
            <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z"/>
          </svg></a></td>
            <td><a href="#" title="" class="update-cart" onclick="toModal(${element.product_id});" data-bs-toggle="modal" data-bs-target="#addCheckOut"><svg xmlns="http://www.w3.org/2000/svg"  fill="currentColor" class="bi bi-check2-square" viewBox="0 0 16 16">
            <path d="M3 14.5A1.5 1.5 0 0 1 1.5 13V3A1.5 1.5 0 0 1 3 1.5h8a.5.5 0 0 1 0 1H3a.5.5 0 0 0-.5.5v10a.5.5 0 0 0 .5.5h10a.5.5 0 0 0 .5-.5V8a.5.5 0 0 1 1 0v5a1.5 1.5 0 0 1-1.5 1.5H3z"/>
            <path d="m8.354 10.354 7-7a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0z"/>
          </svg></a></td>
      
          </tr>


              
            `;
            count++;
        });
        $('#tblCart').append(str);
    },
    error: function(xhr, ajaxOptions, thrownError){
        alert(thrownError);
    }
    });
}

var viewCartsNumber =()=>{
    $.ajax({
        type: "POST",
        url: "./source/router.php",
        data: {choice: 'cartsNumber'},
        success: function(data){
        var json = JSON.parse(data);
        $('#cartNumber').append(json.length);
        },
        error: function(xhr, ajaxOptions, thrownError){
        alert(thrownError);
        }
    });
}
  
var updateFunction =(id)=>{
    if(confirm("Are you sure you want to update this item")){
        $.ajax({
            type: "POST",
            url: "./source/router.php",
            data: {choice: 'doUpdateCartQuery', Quantity:$('#updateNumber').val(), ID:id},
            success: function(data){
                if(data == 200){
                    window.location.href = "./shopcart.php";
                }else{
                    alert(data);
                }
            },
            error: function(xhr, ajaxOptions, thrownError){
              alert(thrownError);
            }
        });
    }else{
        window.location.href = "shopcart.php";
    }
}

var deleteFunction =(id)=>{
    if(confirm("Are you sure you want to delete this item")){
        $.ajax({
            type: "POST",
            url: "./source/router.php",
            data: {choice: 'doDeleteCartQuery', ID:id},
            success: function(data){
                if(data == 200){
                    window.location.href = "./shopcart.php";
                }else{
                    alert("Deleted Failed!");
                }
            },
            error: function(xhr, ajaxOptions, thrownError){
                alert(thrownError);
            }
        });
    }
}

var deleteAfterAddInOrder =(id)=>{
    $.ajax({
        type: "POST",
        url: "./source/router.php",
        data: {choice: 'doDeleteCartQuery', ID:id},
        success: function(data){
            location.reload();
        },
        error: function(xhr, ajaxOptions, thrownError){
            alert(thrownError);
        }
    });
}

function onAddToOrder(title, total, qt){
    $.ajax({
      type: "POST",
      url: "./source/router.php",
      data: {choice:'doInsertOrder',title:title, total_price:total, Qt:qt, address:$('#addressOrder').val(), P_method:$('#paymentOrder').val(),status:1},
      success: function(data){

      },
      error: function(xhr, ajaxOptions, thrownError){
        alert(thrownError);
      }
    });
}

function viewMyOrder(p, t, pr, total, quan, img){
    $.ajax({
        type: "POST",
        url: "./source/router.php",
        data: {choice:'doinsertManageOrder',productUser_Id:p, title:t, price:pr, total_price:total, Qt:quan, image:img, p_method:$('#paymentOrder').val()},
        success: function(data){
          alert(data);
        },
        error: function(xhr, ajaxOptions, thrownError){
          alert(thrownError);
        }
    });  
}

function toModal(id){
    $.ajax({
        type: "POST",
        url: "./source/router.php",
        data: {choice: 'doCartTableToOrder', Item:id},
        success: function(data){
        var json = JSON.parse(data);
        str = "";
        json.forEach(element => {
            str = `
                <div class="row  d-flex justify-content-center">
                    <div class="col-10 fs-1">
                        <label class="label"for="">Address</label>
                        <div class="input-group">
                                <input type="text" class="form-control" name="addressOrder" id="addressOrder"placeholder="Please provide your Complete Address" required>
                        </div>
                        </div>

                        <div class="col-20 fs-3">
                        <label class="pay"for=""> Payment method</label>
                        <div class="input-group-sm fs-3">                       
                            <select name="paymentOrder" id="paymentOrder" onclick="checkValuePicked()" placeholder=""required>
                                <option value="COD">Please choose your payment</option>
                                <option value="COD" id="cod">Cash On Delivery</option>
                                <option value="gcash" id="gcash">Gcash</option>
                            </select>
                        </div>
                        </div>
                        <div class="order">
                            <button type="button" class="orders" id="sadsadsad" onclick="onAddToOrder('${element.title}', '${element.total_price}', '${element.Qt}'); deleteAfterAddInOrder(${element.id}); viewMyOrder('${element.user_id}', '${element.title}', '${element.price}', '${element.total_price}', '${element.Qt}', '${element.image}'); ">Place Order</button>
                        </div>
                    
                </div>
            `;
        });
        $('#addthisItemToCart').empty().append(str);
        },
        error: function(xhr, ajaxOptions, thrownError){
        alert(thrownError);
        }
    });
}
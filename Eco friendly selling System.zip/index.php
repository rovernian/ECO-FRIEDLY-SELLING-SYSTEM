<?php
    include("./includes/header.php");
?>
<body>
    
<!-- header section starts  -->

<header class="header">

    <a href="#" class="logo"> <i class="fas fa-shopping-basket"></i> Ecoshop </a>

    <nav class="navbar">
        <a href="#home">home</a>
       <a href="#products">products</a>
    </nav>

    <div class="icons">
        <div class="fas fa-bars" id="menu-btn"></div>
        <div class="fas fa-search" id="search-btn"></div>
        <a href="login/index.php"><div class="fas fa-shopping-cart" id="cart-btn"></div></a>
        <div class="fas fa-user" id="login-btn"></div>
    </div>

    <form action="" class="search-form">
        <input type="search" id="search-box" placeholder="search here...">
        <label for="search-box" class="fas fa-search"></label>
    </form>

 

    <form action="" class="login-form">
        <h3>login now</h3>
        <input type="email" id="email" placeholder="your email" class="box">
        <input type="password" id="password" placeholder="your password" class="box">
        <p>don't have an account <a href="./login/signup.php">create now</a></p>
        <input type="button" id="btnLogin" value="login now" class="btn">
    </form>
</header>



<section class="home" id="home">

    <div class="content">
        <h3>Create your own <span>HANDMADE</span> products</h3>
        <p>and show the world how  beautiful Eco-friendly thing is... </p>
        <a href="./login/signup.php" class="btn">shop now</a>
    </div>

</section>




<section class="products" id="products">

    <h1 class="heading"> Eco <span>products</span> </h1>

    <div class="swiper product-slider">

        <div class="swiper-wrapper">

            <div class="swiper-slide box">
                <img src="images/eco-jute-bags (1).jpeg" alt="">
                <h3> jute bag</h3>
                <div class="price">₱500</div>
              
                <a href="#" class="btn">add to cart</a>
            </div>

            <div class="swiper-slide box">
                <img src="images/DSC01369.webp" alt="">
                <h3>logo eco-totebag</h3>
                <div class="price">₱500</div>
               
                <a href="#" class="btn">add to cart</a>
            </div>

            <div class="swiper-slide box">
                <img src="images/3774f2_e9b4b4d7d5fe47a588c6232f0a38e0a6~mv2.webp" alt="">
                <h3>Reusable tote bag</h3>
                <div class="price">₱500 </div>
               
                <a href="#" class="btn">add to cart</a>
            </div>

            <div class="swiper-slide box">
                <img src="images/images.jpg" alt="">
                <h3>Recycle Plastic bag</h3>
                <div class="price">₱500</div>
               
                <a href="#" class="btn">add to cart</a>
            </div>

        </div>

    </div>

    <div class="swiper product-slider">

        <div class="swiper-wrapper">

            <div class="swiper-slide box">
                <img src="images/organic-eco-friendly-biodegradable-areca-leaf-dinner-plate-original-imag2vb9qmqn9fxb.webp" alt="">
                <h3>Miessence Organic shampoo</h3>
                <div class="price"> ₱500 </div>
               
                <a href="#" class="btn">add to cart</a>
            </div>

            <div class="swiper-slide box">
                <img src="images/342cac6aa9b9f8598e04d9c1f4b59581.jpg" alt="">
                <h3>Handmade organic bird Purse</h3>
                <div class="price">₱500 </div>
              
                <a href="#" class="btn">add to cart</a>
            </div>

            <div class="swiper-slide box">
                <img src="images/Eco-Containers-1.webp" alt="">
                <h3>Organic Painted Fillow</h3>
                <div class="price"> ₱500</div>
               
                <a href="#" class="btn">add to cart</a>
            </div>

            <div class="swiper-slide box">
                <img src="images/81dw37gQulS._SL1500_-e1648059718182.webp" alt="">
                <h3>12-pcs Bamboo Dinnerware set</h3>
                <div class="price"> ₱500</div>
              
                <a href="login/index.php" class="btn">add to cart</a>
            </div>

        </div>

    </div>


</section>











<?php
include("./includes/footer.php");
?>


<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="javaScript/jquery.js"></script>
<script src="javaScript/toggle.js"></script>
<script src="javaScript/Userlogin.js"></script>
<script src="javaScript/script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


</body>
</html>